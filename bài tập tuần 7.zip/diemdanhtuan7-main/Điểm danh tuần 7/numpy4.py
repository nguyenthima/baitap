X = np.array([2, 5, 3, 1, 7])
Y = np.array([2, 1, 8, 5, 7, 9])

print("Median X = ", np.median(X))
print("Median Y = ", np.median(Y))

# Median X =  3.0
# Median Y =  6.0