print("mean a = ", np.mean(a, dtype=np.float64))

# mean a =  0.5500000007450581