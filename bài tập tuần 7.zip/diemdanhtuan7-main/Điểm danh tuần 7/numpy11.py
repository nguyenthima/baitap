print("mean = ", np.mean(x))
print("median = ", np.median(x))

# mean =  nan
# median =  nan