print("Bách phân vị thứ 50: ", np.percentile(scores, 50))
print("Median = ", np.median(scores))

# Bách phân vị thứ 50:  5.5
# Median =  5.5