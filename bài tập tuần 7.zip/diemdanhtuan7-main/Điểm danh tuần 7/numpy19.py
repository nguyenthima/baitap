print("Q1 = : ", np.quantile(scores, 0.25))
print("Q2 = : ", np.quantile(scores, 0.5))
print("Q3 = : ", np.quantile(scores, 0.75))

# Q1 = :  4.0
# Q2 = :  5.5
# Q3 = :  8.0