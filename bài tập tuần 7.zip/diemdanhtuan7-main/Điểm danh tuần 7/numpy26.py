print("Trung bình số mặt ngửa nhận được khi tung đồng xu 20 lần trong vòng 10 lần lặp: ", np.random.binomial(20, 0.5, 10).mean())

# Trung bình số mặt ngửa nhận được khi tung đồng xu 20 lần trong vòng 10 lần lặp:  10.4
