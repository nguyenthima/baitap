median arr (axis = 0) =  [5.  6.5 3.5]
median arr (axis = 1) =  [4. 5.]

# median arr (axis = 0) =  [5.  6.5 3.5]
# median arr (axis = 1) =  [4. 5.]