m, sigma = 0, 0.1 # mean và standard deviation
# s = np.random.normal(mu, sigma, size=5)
