import numpy as np

X = [1, 2, 3, 4, 5]
print("Mean X = ", np.mean(X))

# Mean X =  3.0

