np.random.binomial(20, 0.5) # Số mặt ngửa nhận được khi tung đồng xu 10 lần
# 9