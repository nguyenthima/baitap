freetuts_visitors = np.array([3776, 3112, 3476, 3319, 3559, 2121, 3462])
print("Số người truy cập trung bình mỗi ngày trong tuần qua của Freetuts: ", np.mean(freetuts_visitors))


# Số người truy cập trung bình mỗi ngày trong tuần qua của Freetuts:  3260.714285714286
