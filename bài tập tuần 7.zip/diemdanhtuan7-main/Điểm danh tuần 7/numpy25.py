np.random.binomial(20, 0.5, 10) # Số mặt ngửa nhận được khi tung đồng xu 20 lần trong 10 lần lặp
array([10, 10,  9,  6, 10, 11, 13, 10,  8,  9])

# array([10, 10,  9,  6, 10, 11, 13, 10,  8,  9])
